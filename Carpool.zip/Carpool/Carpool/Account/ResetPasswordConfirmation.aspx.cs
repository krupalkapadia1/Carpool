﻿using System.Web.UI;

namespace Carpool.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}